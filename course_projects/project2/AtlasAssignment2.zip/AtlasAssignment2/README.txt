This submission contains the following elements:

1. code_submission.py - The code submission that defines the
algorithms and runs the experiments.
2. report2.pdf - The project summary report.
3. std_knn_results.csv - Predictions for the Ecoli dataset for standard  KNN
4. edited_knn_results.csv - Predictions for the Ecoli dataset for Edited KNN
5. condensed_knn_results.csv - Predictions for the Ecoli dataset for Condensed KNN
6. code_walkthrough.mp4 - the video walking through the code running and the overall accuracies.
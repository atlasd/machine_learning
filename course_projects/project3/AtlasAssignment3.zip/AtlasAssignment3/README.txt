This submission contains the following elements:

1. abalone_predictions.csv & wine_predictions.csv - Classification and regression prediction outputs
2. code_submission.py - The code submission to fit the trees and run the experiments
3. code_walkthrough.mp4 - The video showing code functionality
4. report3.pdf - The written submission.
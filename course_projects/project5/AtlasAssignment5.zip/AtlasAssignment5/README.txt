This submission contains the following elements:

1. project5.pdf - The paper associated with this assignment.
2. code_submission.py - The implementation and experiments for the assignment.
3. *_prediction_results.csv - One fold of predictions for each dataset for all the models.
4. walkthrough.mp4 - The video walkthrough of gradient updates and the code submission running.

